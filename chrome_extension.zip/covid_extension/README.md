#Install
1. Unzip somewhere
2. In Chrome, navigate to: chrome://extensions/
3. Click "Load unpacked"
4. Select unzipped project